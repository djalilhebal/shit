class ZeroMedia {
  constructor() {
    this.id = 'chat-id+timestamp';
    this.parts = Array(partsCount).fill(null)
    this.mime = 'image/jpg'
  }
  
}
