function output(candidates) {
	getElementById('candidates').innerHTML = JSON.stringify(candidates);
}
