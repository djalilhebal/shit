# Numbo

Trying to write an app that helps in generating mnemonics using the Phonetic Number System.
Unlike what I found on the internet, I am trying to (hopefully) "generate" meaningful, memorable English phrases/sentences

This thing is pratically unusable! I just decided to upload this draft to GitHub in case I screw the whole thing... (re-writing it)

## Gamma
Gamma's phone numbers:
Currently it only maps each number to a single sound and uses a wordlist of 60K words (actually 14K words after being filtered), but look at the number of combinations when I tried entering two phone numbers:

06XXXXXXXX -> 46,027,351,688,706,584 combos
07XXXXXXXX -> 40,011,115,120,079,220 combos

Obviously checking every one is a big no-no! Also, timeouting this task is no good idea as well... gotta fix this...

## TODO

- Rename functions and variables.

- Consider scoring++ fillers ('well', 'like', 'umm', etc.) since they can be inserted anywhere (?)

- Use heuristics! Maybe by searching/traversing a graph/tree of combinations using a Markov-like model and words' frequencies? Sounds awesome, and then use some rule-based methods shall be used to score them.

- Instead of 'guessingPOS', I should use a pre-tagged wordlist, that's more reliable

- Prepare a list of proverbs/idioms/sayings/quotes/catchy phrases, that might be valid Algerian phone numbers (/0?[567][0-9]{8,8}/) or dates (dd-mm-yyyy).
