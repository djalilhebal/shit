// node app
const numbo = require('./src/index.js');

// introduced in node v8
if (!console.clear) console.clear = function () {};

function output(candidates) {
  const body = candidates.filter(x => x.score !== -1)
    .map((x, i) => `#${i + 1}  ${x.str} (${x.score})`)
    .join('\n');
  console.clear();
  console.info(`\n\tCANDIDATES\n\n==============================\n\n${body}`);
}

if (process.argv.length !== 3 || !/^[0-9]+$/.test(process.argv[2])) {
  console.log('Usage: node numbo [number]');
} else {
  const num = process.argv[2];
  const options = {
    outputFunction: output,
    maxCandidates: 55, // "Quantity, not Quality" :p
    maxTime: 60, // timeout in secs
  };
  numbo.work(num, options);
}
