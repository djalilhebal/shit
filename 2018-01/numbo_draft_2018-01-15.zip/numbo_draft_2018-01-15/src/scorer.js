const scoreByTemplates = require('./scorer.templ.js');
const poetryStuff = require('./scorer.poetry.js');
const misplacedWords = require('./scorer.misplacedWords.js');
// const markovlike = require('./scorer.markovlike.js');
const guessPOS = require('./guessPOS.js');

function getScore(words, phons) {
  // words = ['shitty', 'place']
  // phons = ['XT', 'PLS']
  // tags = ['ADJ', 'NOUN']
  const tags = words.map(guessPOS);
  return scoreByTemplates(words, tags) * 1000 +
  // markovlike(words) * 100 +
      misplacedWords(words, tags) * -10 +
			poetryStuff.scoreSyllables(words) * 1 +
			poetryStuff.rhymingPairs(phons) * 10 +
			poetryStuff.alliterativePairs(phons) * 10;
}

module.exports = getScore;
