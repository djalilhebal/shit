var wnDomains = {
	index: ['biology'],
	'biology': ['egg', 'ant', 'bird', 'bee', 'hive']
}

function scoreTopics(words, topics) {
	/**
	 * @example
	 * scoreTopics(['hive', 'bee'], ['biology']) === 2
	 */
	var result = 0;
	for (topic of topics)
		if (typeof wnDomains[topic] !== 'array') continue;
		for (word of words) if (wnDomains[topic].includes(word)) result++;
	return result;
}
