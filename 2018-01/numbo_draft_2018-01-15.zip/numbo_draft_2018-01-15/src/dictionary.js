const myMetaphone = require('./myMetaphone.js');
const fs = require('fs');

var dictionary         = {};
    dictionary.entries = {};
    dictionary.index   = [];
    dictionary.count   = 0;
var rCode              = /^[SLNMRVBTXG]+$/;
var rWord              = /^[-a-z]+$/i;

function addWord(word, phon) {
	if (!phon) phon = myMetaphone(word);
	if (rWord.test(word) && rCode.test(phon)) {
		if (!dictionary.index.includes(phon)) {
			dictionary.index.push(phon);
			dictionary.entries[phon] = [];
		}
		// idk why but dups exist, avoid them
		if (!dictionary.entries[phon].includes(word)) {
			dictionary.entries[phon].push(word);
			dictionary.count++;
		}
	}
}

function cmuToMyCode(input) {
	/**
	 * @example
	 * cmuToMyCode("W AA1 CH ER0") === "XR" // WATCHER
	 * cmuToMyCode("V AY1 B Z") === "VBS" // VIBES
	 */

    return input.split(' ').map(function(chr){
		if (chr == 'R' || chr == 'ER0' || chr == 'ER1' || chr == 'ER2') return 'R';
		if (~chr.indexOf('0') || ~chr.indexOf('1') || ~chr.indexOf('2') ) return '';
		if (chr == 'HH') return '';
		if (chr == 'SH' || chr == 'CH') return 'X';
		if (chr == 'ZH' || chr == 'JH') return 'J';
		if (chr == 'Z') return 'S';
		return chr;
	}).join('');
}

function fromCMUdict(path) {
	if (!path) path = './src/cmudict.txt';
	fs.readFileSync(path, 'utf8').split('\n').forEach(function(line) {
		// ignore comments; and get only the prime pronun
		if (line.indexOf(';;;') < 0 && line.indexOf(')') < 0) {
			var word = line.toLowerCase().slice(0, line.indexOf(' '));
			var phon = cmuToMyCode(line.slice(line.indexOf(' ')));
			addWord(word, phon);
		}
	});
}

function fromPlainWordlist(path){
	if (!path) path = './src/wordlist.txt';
	fs.readFileSync(path, 'utf8').split('\n').forEach( word => addWord(word) );
	return dictionary;
}

function fromModel(model) {
	model.index.forEach( word => addWord(word) );
}

function makeDic() {
	fromPlainWordlist();
	dictionary.index.sort( (a, b) => b.length - a.length );
	return dictionary;
}

module.exports = makeDic;
