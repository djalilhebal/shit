const getScore = require('./scorer.js');
const makeDic = require('./dictionary.js');

let dictionary; // {GRT: ['great'], GR: ['gray', 'grow'], ... }
let phonetics; // dictionary.index ['GRT', 'GR', ...]

let output; // fn

let candidates;

let setsOfWordSets;
let combos; // numberOfCombs 
let wordSets;
let phons;

let startTime;
let maxTime;
const timeout = () => (Date.now() - startTime) / 1000 > maxTime; // maxTime in secs

const code = ['S', 'L', 'N', 'M', 'R', 'V', 'B', 'T', 'X', 'G'];

function encodeNumber(num) {
  return String(num).split('').map(x => code[Number(x)]).join('');
}

function numberOfCombs(wordSets) {
 /**
  * THE NUMBER OF CARTESIAN COMBINATIONS
  * @example
  * numberOfCombs([ [1] ]) === 1;
  * numberOfCombs([ [1, 2] ]) === 1;
  * numberOfCombs([ [1, 2], [3]]) === 2;
  * numberOfCombs([ [1, 2], [3, 4]]) === 4;
  */
  let result = 1;
  wordSets.forEach((wordSet) => {
    result *= wordSet.length;
  });
  return result;
}

function doWordSets(seq) {
  if (!seq || timeout()) return false;
  for (let i = 0; i < phonetics.length; i++) {
    if (timeout()) return;
    const phon = phonetics[i];
    if (seq.indexOf(phon) === 0) {
      phons.push(phon);
      wordSets.push(dictionary[phon]);
      const newSeq = seq.slice(phon.length);
      if (newSeq) {
        doWordSets(newSeq);
      } else {
        //console.log(`${phons.join('-')} (${numberOfCombs(wordSets)})`);
        combos += numberOfCombs(wordSets);
        setsOfWordSets.push(wordSets.slice(0));
      }
      phons.pop();
      wordSets.pop();
    }
  }
}

function cartesian(sets) {
  // NOT MINE
  const max = sets.length - 1;
  function helper(arr, i) {
    if (timeout()) return;
    for (let j = 0, l = sets[i].length; j < l; j++) {
      const a = arr.slice(0); // clone arr
      a.push(sets[i][j]);
      if (i === max) handleCombination(a); else helper(a, i + 1);
    }
  }
  helper([], 0);
}

function handleWordSets(wordSets) {
  if (timeout()) return;
  cartesian(wordSets);
  output(candidates);
}

function handleCombination(words) {
  if (timeout()) return;

  const score = getScore(words, phons.join(' '));
  if (score > candidates[candidates.length - 1].score) {
    candidates.pop();
    candidates.push({ str: words.join(' '), score });
    candidates.sort((a, b) => b.score - a.score);
  }
}

function work(number, settings) {
  if (!dictionary) {
    console.log('preparing the wordlist...');
    console.time('makeDic');
    let raw_dictionary = makeDic();
    dictionary = raw_dictionary.entries;
    phonetics = raw_dictionary.index;
    console.timeEnd('makeDic');
  }

  if (!settings) settings = {};
  const maxCandidates = settings.maxCandidates || 25;

  output = settings.outputFunction || console.log;
  maxTime = settings.maxTime || 60; // secs
  startTime = Date.now();

  candidates = [];
  for (let i = 0; i < maxCandidates; i++) candidates[i] = { str: '', score: -1 };

  combos = 0;
  
  setsOfWordSets = []; wordSets = []; phons = [];
  console.time('doWordSets');
  doWordSets(encodeNumber(number));
  console.timeEnd('doWordSets');

  console.time('setsOfWordSets.sort');
  setsOfWordSets.sort((a, b) => numberOfCombs(a) - numberOfCombs(b));
  console.timeEnd('setsOfWordSets.sort');

  setsOfWordSets.forEach(set => handleWordSets(set));
  output(candidates);
  console.info('\n[[ ' + number + ' has ' + combos + ' combos ]]');
}
module.exports = { work };
