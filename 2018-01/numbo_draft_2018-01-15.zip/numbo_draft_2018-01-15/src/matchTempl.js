const guessPOS = require('./guessPOS.js');

function matchTemplate(words, _tmp, unsure) {
  /**
   * @example
   * matchTemplate('she is very gorgeous', 'she is #adv #adj indeed?') === true
   */
  const tmp = _tmp.split(' ').reverse();
  if (!words || !words.length || !tmp.length) return false;
  let word,
    exp,
    isOptional,
    pos,
    i = 0;

  while (tmp.length) {
    word = words[i];
    exp = tmp.pop(); // expected

    if (exp.startsWith('#')) {
      exp = exp.toUpperCase().slice(1);
      isExact = false;
    } else {
      isExact = true;
    }

    if (exp.endsWith('?')) {
      exp = exp.slice(0, -1);
      isOptional = true;
    } else {
	  isOptional = false;
    }

    if (isExact) { // exact matching
      if (exp !== word) {
        if (isOptional) continue; else return false;
      }
    } else { // PoS matching
	  pos = guessPOS(word);
	  // not matching the expected PoS, even after treating GERUNDs as ADJ/NOUN?
      if (!(exp === pos) && !(pos === 'GERUND' && (exp === 'ADJ' || exp === 'NOUN')) && !(unsure && pos === 'UNSURE')) {
        if (isOptional) continue; else return false;
      }
    }

    i++;
  }
  return words.length === i;
}

module.exports = matchTemplate;
