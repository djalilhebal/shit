const fs = require('fs');

let model = {};
	model._index = new Set(['START']);

function inc(a, b) {
	// a -> b
	if (typeof model[a] === 'undefined') model[a] = {};
	if (typeof model[a][b] === 'undefined') model[a][b] = 0;
	++model[a][b];
}

function getText(path) {
	if (!path) path = 'corpus.txt';
	return fs.readFileSync(path, 'utf8');	
}

function getCleanText(text) {
	// normalizeText (remove emphasis quotes, and emoji)
	return text;
}

function getSentences(text) {
	const rPhraseSeparators = /[\(\)\!\?\.\n]+/;
	return text.split(rPhraseSeparators);
}

function getWords(str) {
	const rWord = /^[-a-z]+$/;
	return str.split(' ').map( x => x.toLowerCase() ).filter( x => rWord.test(x) );
}

function doWords(words) {
	for (let i = 0; i < words.length; i++) {
		model._index.add(words[i]);
		if (i === 0) inc('START', words[i]);
		if (i === words.length - 1) {
			inc(words[i], 'END');
		} else {
			inc(words[i], words[i + 1]);
		}
	}
}

function simplifyModel(model) {
	/*	model = {
			START: {so: 16, I: 70, 'then': 4},
			so : {cool: 55, what: 9}
		}
		newModel = {
			START: ['I', 'so', 'then'],
			so : ['cool', 'what']
			// ...
		}
	*/
	let newModel = {};
	model._index.forEach( entry => {
		newModel[entry] = Object.keys(model[entry]).sort( (a, b) => model[entry][b] - model[entry][a])
	});
	return newModel;
}

console.log(JSON.stringify(simplifyModel(model)));

//module.exports = model;
