const matchTemplate = require('./matchTempl.js');

function scoreByTemplates(words) {
  const templates = [
    'be #adj',              // 'be happy'
    '#adv #adj',            // 'hopelessly hopeful'
    '#adv? #adj and #adj',  // 'very stylish and classy'
    'such #adj #noun',      // 'such interesting alibi'
    '#adv? #verb #noun',    // 'always utilize Android'
    'what #dit #adj #noun',  // 'what an amazing man'
    '#dit? #adv? #adj #noun', // 'an awfully dirty place'
    '#dit? #adj? #noun #modal? #verb #noun?', // 'any calamity can darken kingdoms'
    '#dit? #adj? #noun and #dit? #adj? #noun', // 'handsome man and pretty woman'
  ];
  if (templates.some(template => matchTemplate(words, template, false))) return 1;
  if (templates.some(template => matchTemplate(words, `see ${template}`, false))) return 0.75;
  if (templates.some(template => matchTemplate(words, `still ${template}`, false))) return 0.75;
  if (templates.some(template => matchTemplate(words, `so? as? ${template}`, false))) return 0.5;
  if (templates.some(template => matchTemplate(words, template, true))) return 0.25;
  return 0;
}

module.exports = scoreByTemplates;
