/*
TODO:
- sort each entry's words by frequency
- use a pronun dic if exists, else fallback to 'myMetaphone'
*/

const myMetaphone = require('./myMetaphone.js');
const decoder = require('./decoder.js');
const fs = require('fs');

const rCode              = /^[SLNMRVBTXG]+$/;
const rWord              = /^[-a-z]+$/i;

let dictionary         = {};
    dictionary.entries = {};
    dictionary.index   = [];
    dictionary.count   = 0;

function addWord(word, phon) {
	if (!phon) phon = myMetaphone(word).replace(/D/g, 'B').replace(/F/g, 'T');
	if (rWord.test(word) && rCode.test(phon)) {
		if (!dictionary.index.includes(phon)) {
			dictionary.index.push(phon);
			dictionary.entries[phon] = [];
		}
		// to avoid dups
		if (!dictionary.entries[phon].includes(word)) {
			dictionary.entries[phon].push(word);
			dictionary.count++;
		}
	}	
}

function fromCMUdict(path) {
	if (!path) path = './cmudict.txt';
	fs.readFileSync(path, 'utf8').split('\n').forEach(function(line) {
		// ignore comments; and get only the prime pronun
		if (line.indexOf(';;;') < 0 && line.indexOf(')') < 0) {
			var word = line.toLowerCase().slice(0, line.indexOf(' '));
			var phon = decoder.arpabet(line.slice(line.indexOf(' ')));
			addWord(word, phon);
		}
	});
}

function fromPlainWordlist(path){
	if (!path) return false;
	fs.readFileSync(path, 'utf8').split('\n').forEach( word => addWord(word) );
	return true;
}

function fromModel(path) {
	require(path).index.forEach( word => addWord(word) );
}

//fromPlainWordlist('./wordlist.txt');
fromModel('./modelA.json');

dictionary.index.sort( (a, b) => b.length - a.length );
console.log(JSON.stringify(dictionary));
