function cartesianGenerator(group, fn, startTime, maxTime) {
	// call `fn` after generating each combination
  const sets = group.sets;
  const max  = sets.length - 1;
  
  function helper(arr, i) {  
	// if it's timed out, stop (maxTime in secs)
    if ((Date.now() - startTime) > maxTime * 1000) return;
    for (let j = 0; j < sets[i].length; j++) {
      const c = arr.slice(0); // clone arr
      c.push(sets[i][j]);
      if (i === max) fn(c, group.phons); else helper(c, i + 1);
    }
  }
  
  helper([], 0);
}

function intersect(a = [], b = [], max = 1) {
	/**
	 * get an array of at most 'max' elements that exist in both 'a' and 'b'
	 * while preserving the ordering of 'a'
	 *
	 * @example
	 * intersect([1,2], [3,4], 2); // []
	 * intersect([0,1], [8, 9, 0], 2); // [0]
	 * intersect([1,2,3,4,5], [7,6,5,4,3], 2); // [3,4]
	 */
	 
	let result = [];
	for (let i = 0; i < a.length; i++) {
		if (b.includes(a[i])) result.push(a[i]);
		if (result.length === max) break;
	}
	return result;
}

function markovGeneratorB(model, wordSets) {
	// from the END: wonderland, in, alice
  let result = [];
  for (let i = wordSets.length - 1; i >= 0 ; i--){
	  let r;
	  if (i === wordSets.length - 1) {
		  r = intersect(model.entries.STOP, wordSets[i]);
	  } else {
		  r = intersect(model.entries[ result[result.length - 1] ], wordSets[i]);
	  }
	  if (r.length) {
		result.push( r[0] );  
	  } else {
	  	result.push( wordSets[i][0] );  
	  }
  }
  return result.reverse();
}

function markovGeneratorA(model, wordSets, take = 0) {
	// from the START: alice, in, wonderland
  let result = [];
  for (let i = 0; i < wordSets.length; i++){
	  let r;
	  if (i === 0) {
		  r = intersect(model.entries.START, wordSets[0]);
	  } else {
		  r = intersect(model.entries[ result[result.length - 1] ], wordSets[i]);
	  }
	  if (r.length >= take + 1) {
		result.push( r[take] );  
	  } else {
		  if (wordSets[i].length >= take + 1) {
			  	result.push( wordSets[i][take] );  
		  } else {
			  	result.push( wordSets[i][0] );  
		  }
	  }
  }
  return result;
}

module.exports = { markovGeneratorA, markovGeneratorB, cartesianGenerator };
