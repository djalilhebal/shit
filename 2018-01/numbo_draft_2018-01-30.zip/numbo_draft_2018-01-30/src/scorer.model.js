// b.sortBy frequency

/*
model = {
	START: ['you', 'Alex', 'Kaito', 'so', 'since'],
	Kaito: ['says', 'is', 'does', 'and'],
	is:    ['an', 'just'],
	good:  ['END', 'girl', 'boy', 'person', 'guy'],
	boy:   ['END', 'is', 'has', 'really'],
	//...
}
*/
function scoreUsingModel(words, model) {
	/**
	 * @example
	 * scoreModel(['Kaito', 'is', 'good', 'boy'], model) === 3
	 * // START->Kaito->is / good->boy
	 */
	let result = 0;
	for (let i = 0; i < words.length; i++) {
		if (i === 0) {
			if ( model.START.includes(word) ) result++
		} else {
			if ( model.[ words[i-1] ].includes(word) ) result++
		}
	}
	return result;
}
