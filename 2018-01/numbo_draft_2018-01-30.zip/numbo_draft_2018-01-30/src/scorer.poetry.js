function alliterativePairs(str) {
 // 'fairly fine' -> 1
  const m = str.match(/(\w)\w* \1\w*/g) || [];
  return m.length;
}

function rhymingPairs(str) {
 // 'good food' -> 1
  const m = str.match(/\w*(\w) \w*\1/g) || [];
  return m.length;
}

function scoreSyllables(words) {
 /**
  * @example
  * countSyllables('Gamma is my friend'.split(' ')) === 5;
  */
  function syllables(word) {
  /** NOT MINE -- Count syllables in a word */
    word = word.toLowerCase();
    if (word.length <= 3) return 1;
  // Magic vowel regex replace thing, do not touch
    word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '');
    word = word.replace(/^y/, '');
    const matched = word.match(/[aeiouy]{1,2}/g);
    if (!matched) return 1;
    return matched.length;
  }

  let result = 0;
  words.forEach((word) => {
    result += syllables(word);
  });
  return (result >= 5 && result <= 10) ? 1 : 0;
}

module.exports = { alliterativePairs, rhymingPairs, scoreSyllables };
