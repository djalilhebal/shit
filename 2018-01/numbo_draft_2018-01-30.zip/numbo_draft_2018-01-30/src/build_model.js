/*
TODO:
- delete words that won't be used
- generate modelA and modelB at the same time
- automatically write models to disk
*/

const rev = false;
const fs = require('fs');

let model = {};
	model.index = new Set();
	model.entries = {};

function inc(a, b) {
	// a -> b
	if (typeof model.entries[a] === 'undefined') model.entries[a] = {};
	if (typeof model.entries[a][b] === 'undefined') model.entries[a][b] = 0;
	model.entries[a][b]++;
}

function getSentences(text) {
	const rPhraseSeparators = /["“”;:\(\)\.\!\?\r\n]+/;
	return text.split(rPhraseSeparators).filter( x => x.length > 0 );
}

function getWords(str) {
	str = 'START ' + str + ' STOP';
	const rWord = /^[a-z]([a-z'-])*[a-z]$/i;
	const blacklist = ['a', 'i', 'you', 'we', 'he'];
	return str.split(' ').filter( x => rWord.test(x) && !blacklist.includes(x) );
}

function doWords(words) {
	// words = START kaito is happy STOP
	if (rev) words.reverse(); // words = STOP happy is kaito START
	
	for (let i = 0; i < words.length; i++) {
		model.index.add(words[i]);
		inc(words[i], words[i + 1]);
	}
}

function updateModel(path) {
	if (!path) return;
	
	let text = fs.readFileSync(path, 'utf8')
		.replace(/\b[IVXM]+\b/g, ' ') // remove Romain numerals
		.toLowerCase()
		.replace(/'ll\b/g, ' will')
		.replace(/'d\b/g, ' would')
		.replace(/\b[^a-z]/g, ' ')
		.replace(/[^a-z]\b/g, ' ')
		.replace(/--/g, ' : ') // "something--something" -> "something : something"
		.trim();
	let strs = getSentences(text);
	text = null;
	strs.forEach(str => doWords(getWords(str)));
}

function count(entry) {
	let result = 0;
	let info = model.entries[entry];
	Object.keys( info ).forEach( key => { result += info[key]; });
	return result;
}

function getSimplifiedModel() {
	/*	{ // before
			START: {so: 16, I: 70, 'then': 4},
			so : {cool: 55, what: 9}
		}
		
		{ // after
			START: ['I', 'so', 'then'],
			so : ['cool', 'what']
			// ...
		}
	*/
	
	let newModel = {};
	
	newModel.index = [...model.index];
	newModel.index.sort( (a, b) => count(b) - count(a) );
	
	newModel.entries = {};
	model.index.forEach( entry => {
		newModel.entries[entry] = Object.keys(model.entries[entry]);
		newModel.entries[entry].sort( (a, b) => model.entries[entry][b] - model.entries[entry][a] );
		newModel.entries[entry] = newModel.entries[entry].slice(0, 100);
	});
	
	return newModel;
}

updateModel('./jokes.txt');
updateModel('./crpy3.txt');
updateModel('./carroll.txt');
updateModel('./orwell.txt');
//updateModel('./dickens.txt');
updateModel('./aristotle.txt');

console.log(JSON.stringify( getSimplifiedModel() ));
