// functions to convert from THEIR phon sets to MINE...

function ipa(input) {
	/**
	 * IPA is used by wiktionary
	 */
}

function sampa(input) {
	/**
	 * SAMPA is used by unisyn
	 */
}

function arpabet(input) {
	/**
	 * Arpabet is used by cmudict
	 * 
	 * @example
	 * arpabetToMyCode("W AA1 CH ER0") === "XR" // WATCHER
	 * arpabetToMyCode("V AY1 B Z") === "VBS" // VIBES
	 */

    return input.split(' ').map(function(chr){
		if (chr == 'R' || chr == 'ER0' || chr == 'ER1' || chr == 'ER2') return 'R';
		if (~chr.indexOf('0') || ~chr.indexOf('1') || ~chr.indexOf('2') ) return '';
		if (chr == 'HH') return '';
		if (chr == 'SH' || chr == 'CH') return 'X';
		if (chr == 'ZH' || chr == 'JH') return 'J';
		if (chr == 'Z') return 'S';
		return chr;
	}).join('');
}

module.exports = {arpabet}
