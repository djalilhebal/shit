// node app
const numbo = require('./src/index.js');

function output(candidates) {
  const body = candidates.filter(x => x.score !== -1)
    .map((x, i) => `#${i + 1}  ${x.str} (${x.score})`)
    .join('\n');
  console.info(`\n\tCANDIDATES\n\n==============================\n\n${body}`);
}

if (process.argv.length !== 3 || !/^[0-9]+$/.test(process.argv[2])) {
  console.log('Usage: node numbo [number]');
} else {
  const num = process.argv[2];
  const options = {
    maxCandidates: 50, // "Quantity, not Quality" :p
    maxTime: 30, // timeout in secs
  };
  output(numbo.getCandidates(num, options));
}
