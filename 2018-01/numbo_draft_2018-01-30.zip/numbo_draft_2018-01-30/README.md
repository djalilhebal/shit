# Numbo
A Phonetic Number System mnemonics generator

Given a number, it (hopefully) generates some meaningful/memorable phrases/sentences:
"102264126" > "LSNNDRLND" > "LS N NDRLND" > "alice in wonderland"

The included json files were built from: Jokes 4.0 app data (com.objectifiedapps.jokespro), Creepypasta Stories 1.7 app data (com.asdapps.creepypastaindonesia), The Complete Works of Lewis Carroll, George Orwell, and Aristotle.

## Why?
The open-source projects I found are limited, they only generate word sets: 2Know (Java), Adi Mukherjee's mnemonic-major (JavaScript), maleadt's majormem (Perl/C++)

(The same goes with the 'closed-source' web and Android apps I came across)

## TODO

- Consider scoring++ fillers ('well', 'like', 'umm', etc.) since they can be inserted anywhere (?)

- Consider Parts-of-Speech and use an n-gram language model instead of "myMarkov" (a simplistic unigram model)

- Instead of 'myMetaphone', use a pronunciation dictionary like "CMUDict" or "Unisyn" 

- parseLisp (for the prebuilt Unisyn wordlist): ("daydreamer" nn (((d ei) 1) ((d r ii m) 2) ((@) 0)))

- Instead of 'guessPOS', use a more reliable method, like a pre-tagged wordlist or something
(like Unisyn: "dream::NN/VBP/VB: { d r * ii m } :{dream}:14057")

- Instead of WordNet Domains and the likes, it would be awesome if I could find a (shittier) alternative that doesn't require a dataset

## Credit
Apache, Stack-Overflow

## License
WTFPL (._.)
