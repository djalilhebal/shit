// DATA MANAGER
/*
content = {
	name: "tags"
	updated: "yyyymmdd"
	content: {...}
}
*/

const actualData = {};
const data = { // working data
	canUseCartesien: false,
	canUseLanguageModel: false,
	canUseDomains: false,
};

function link(){
	if (typeof actualData.wordlist === 'object') {
		data.canUseCartesien = true;
		data.wordlist = actualData.wordlist;
	}

	if (typeof actualData.pronun === 'object') { // the same with PoS
		data.pronun = actualData.pronun;
	} else {
		if (typeof actualData.tempPronun !== 'object') {
			// generate tempPronun using myMetaphone
		}
		data.pronun = actualData.tempPronun;
	}

	if (typeof actualData.modelA === 'object') {
		data.useModelA = true;
		data.modelA = actualData.modelA;
	} else {
		data.useModelA = false;
	}

	if (typeof actualData.domains === 'object') {
		data.canUseDomains = true;
		data.domains = actualData.domains;
	} else {
		data.useDomains = false;
	}
}

function updateContent(str_data) {
	if (typeof str_data !== 'string') throw;
	const parsed = JSON.parse(str_data);
	if (typeof parsed !== 'object') throw;
	
	Object.keys(parsed).forEach( p => {
		data[p] = parsed[p];
	});
	
	link();
}

module.exports = {updateContent, data, actualData};
