module.exports = {
	normalize: require('./language.normalizer'),
	tokenize: require('./language.tokenizer'),
	modeler: require('./language.modeler'),
}
