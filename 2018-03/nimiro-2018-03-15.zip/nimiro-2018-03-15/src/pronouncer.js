const myMetaphone = require('./pronouncer.myMetaphone.js');
const reEncoder = require('./pronouncer.reEncoder.js');

const dict = {};

function set(word, pronun) {
	if (typeof word !== 'string' || typeof pronun !== 'string') return;
	dict[word] = pronun.replace(/D/g, 'B').replace(/F/g, 'T'); // TODO
}

function load_cmudict(text) {
	if (typeof text !== 'string') throw new Error(text);
	
	const lines = text.split('\n');
	lines.forEach((line) => {
    // ignore comments && get only the prime pronun
    if (line.indexOf(';;;') < 0 && line.indexOf(')') < 0) {
      const word = line.toLowerCase().slice(0, line.indexOf(' '));
	  const arpa = line.slice(line.indexOf(' ')).trim();
      const mine = reEncoder.arpabet(arpa);
      set(word, mine);
    }
  });
}

function load_unisyn(text) {
	// TODO
}

function pronounce(word) {
  if (typeof dict[word] === 'undefined') set(word, myMetaphone(word));
  return dict[word];
}

module.exports = {
	pronounce,
	load_cmudict,
	load_unisyn,
	myMetaphone,
	reEncoder,
};
