function matchTemplate(words, tags, _tmp) {
  /**
   * @example
   * matchTemplate(
		['she', 'is', 'happy'],
		['N', 'V', 'ADJ'],
		'she is #adv? #adj'
		) === true
   */
  const tmp = _tmp.split(' ').reverse();
  if (!words || !tags || !tmp.length || words.length !== tags.length) {
	  console.error('matchTemplate: ', arguments);
	  return false;
  }
  if (words.length > tmp.length) return false;
  
  let exp, word, pos, isOptional, isExact, i = 0;

  while (tmp.length) {
    word  = words[i] || '';
    pos   = tags[i] || '';
    exp   = tmp.pop(); // expected

    if (exp.startsWith('#')) {
      isExact = false;
      exp = exp.toUpperCase().slice(1);
    } else {
      isExact = true;
    }

    if (exp.endsWith('?')) {
      isOptional = true;
      exp = exp.slice(0, -1);
    } else {
	  isOptional = false;
    }

    if (isExact && exp !== word) { // exact matching
        if (isOptional) continue; else return false;
    }
	
	if (!isExact && exp !== pos) { // Part-of-Speech matching
        if (isOptional) continue; else return false;
    }

    i++;
  }
  return words.length === i;
}

module.exports = matchTemplate;
