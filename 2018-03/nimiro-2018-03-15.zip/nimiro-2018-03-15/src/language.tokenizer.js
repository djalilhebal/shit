function tokenize(input) {
	/**
	 * The input should a *normalized* text and returns an array of arrays of words:
	 *
	 * @example
	 * tokenize("Kaito (that would be me) never lies... u don't agree?!")
	 * // [["kaito","never","lies"],["-", "do", "not", "agree"],["that","would","be","me"]]
	 *
	 */

  if (typeof input !== 'string') {
	  console.error('bad input', input);
	  return [];
  }
  
  const sentences = sentence_seg(input);
  const words = sentences.map(sent => word_seg(sent));
  return words;
}

function sentence_seg(str) {
	const rPhraseSeparators = /[;:\.\!\?\r\n]+/;
	return str.split(rPhraseSeparators)
		.map(x => x.replace(/[^a-z'_-]/ig, ' ').replace(/\s+/g, ' '))
		.filter(x => x.length > 0);
}

function cleanWord(word) {
	if (!word) return '';
	return word.replace(/^['-]+/, '').replace(/['-]+$/, '').trim();
}

function word_seg(str) {
	// 'she is f' -> ['she', 'is', '-']
	const words = str.trim()
		  .split(' ')
		  .map(x => cleanWord(x))
		  .filter(x => x.length > 0);
	return words;
}

module.exports = tokenize;
