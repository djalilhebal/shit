const {log, read, write, indexify} = require('./src/helper');
const {normalize, tokenize, modeler} = require('./src/language');
const {pronounce} = require('./src/pronouncer');
const tagger = require('./src/tagger');
const rCode = require('./src/myCode').toRegex();

const files = {
	'corpus': {
		path: './raw_data/corpus.txt',
		exists: true
	},
	'cmudict': {
		path: './raw_data/cmudict-0.7b.txt',
		exists: true
	},
	'liftedWND': {
		path: './raw_data/lifted-wordnet-domains-3.2-wordnet-3.0.txt',
		exists: true
	},
}

function do_raw_model(corpus) {
	log('RAW MODEL...');
	const model = {};
	log('NORMALIZING...');
	let normal = normalize(corpus);
	log('TOKENIZING...');
	let segments = tokenize(normal); normal = null;
	log('MODELLING...')
	modeler.update(model, segments); segments = null;
	
	delete model['-'];
	return model;
}

function do_wordlist(model) {
  log('WORDLIST...');
  const table = {};
  let entries = Object.keys(model);
  entries.forEach((entry) => {
    table[entry] = 0;
    const keys = Object.keys(model[entry]);
	keys.forEach( x => {
		if (x !== '-') table[entry] += model[entry][x];
	});
  });
  entries = entries.filter( entry => table[entry] > 0);
  // sort by freq, IMPORTANT to generate small files
  entries.sort((a, b) => table[b] - table[a]);
  return entries;
}

function do_pronun(wordlist) {
	log('PRONUNCIATION...');
	const dict = {};
	wordlist.forEach( word => {
	  const phon = pronounce(word);
	  if (rCode.test(phon)) {
		if (typeof dict[phon] !== 'object') dict[phon] = [];
		dict[phon].push(word);
	  }
	});
	return dict;
}

function do_domains(wordlist, table) {
  log('LIFTED WORDNET DOMAINS...');
  if (!files.liftedWND.exists) throw 'missing liftedWND';
  let dict = {};
  read(files.liftedWND.path)
  .split('\n')
  .forEach(line => {
	// 02220518-n army_ant#n#1 biology entomology
	// 01170243-a healthy#a#1 medicine
	// (word)#(tag) (domains)
	const rLiftedLine = /^\d+-\w ([a-z_-]+)#([a-z])#\d+ (.+)$/i;
	const m = line.match(rLiftedLine);
	
	if (m) {
	  const word = m[1].toLowerCase();
	  const tag = m[2];
	  const domains = m[3].split(' ');
	  tagger.update(word, tag, 'wnDomains');
	  if (typeof table[word] === 'number') {
	    domains.forEach((domain) => {
	      if (!Array.isArray(dict[domain])) dict[domain] = [];
	      dict[domain].push(table[word]);
	    });
	  }
	}
  });
  
  return dict;
}

function do_tags(wordlist) {
	log('PARTS OF SPEECH...');
	const dict = [];
	wordlist.forEach( (word, i) => {
		dict[i] = tagger.tag(word);
	});
	return dict;
}

function build() {
	log('CLEANING...');
	const fs = require('fs');
	let file = './webapp/module.bundle.js';
	if (fs.existsSync(file)) fs.unlink(file);

	log('READING CORPUS...');
	let corpus = read(files.corpus.path);
	let raw_model = do_raw_model(corpus); corpus = null;

	let wordlist = do_wordlist(raw_model);
	write('./data/wordlist.json', wordlist);
	
	const table = {}; // for the indexifier :p
	wordlist.forEach( (word, i) => {table[word] = i});

	log('MODEL...');
	let model = modeler.simplify(raw_model);
	indexify(model, table);
	write('./data/raw_model.json', raw_model);
	write('./data/model.json', model);
	raw_model = null;
	model = null;
	
	let pronun = do_pronun(wordlist);
	indexify(pronun, table);
	write('./data/pronun.json', pronun);
	pronun = null;
	
	// IMPORTANT: domains and THEN tags
	
	write('./data/domains.json', do_domains(wordlist, table));

	write('./data/taglist.json', do_tags(wordlist));
	
	// child_process.execSync(...)
	// browserify -e src\index.js -s nimiro -o webapp\module.bundle.js
	// java -jar closure-compiler.jar webapp/bundle.js >> webapp/bundle.min.js
	log('[DONE]');
}

build();
