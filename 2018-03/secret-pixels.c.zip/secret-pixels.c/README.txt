# Secret Pixels

So, yesterday (2018-03-29), Kaito learned a new word from his friend Jetto: "Steganography".
Kai skimmed through its Wikipedia article and was very disappointed: he thought he had come up with the coolest idea ever (HIDING TEXT IN IMAGE'S PIXELS) but then he found out that it's already a known technique...
Feeling devastated, the next day he simply cleaned his "drafty draft" and uploaded it to GitHub.. sad.

## Whys
Why use Thoth's picture as an example?
Obviously because he's the Egyptian god who, like, invented writing and shit...

Why support only the PNG image format?
Because it's very popular, libre (non-patented), lossless, and there exists a cutely tiny C header that manipulates it.

Why use C in the first place?
Perhaps because it's, like, more challenging (?) or because it's what we're being taught at the university (?)

## Credit
- It uses tinyheaders' tinypng.h (Public Domain)
- It was developed using Notepad++ and Dev-C++ (viva Open-Source Software >o<)
- I don't own the Thoth image, check: https://commons.wikimedia.org/wiki/File:Thoout,_Thoth_Deux_fois_Grand,_le_Second_Herm%C3%A9s,_N372.2A.jpg

## License
WTFPL
