#include "secret.h"

// 1 on success, 0 on failture
int encode(tpImage img, char *text) {
	int i, len = strlen(text) + strlen(EOM);
	// str = text + EOM; // 'str' is the string to be encoded
	char str[len]; strcpy(str, text); strcat(str, EOM);
	
	int allPixels = img.h * img.w;
	int neededPixels = (len) * 8;
	if (neededPixels > allPixels) return 0;

	bit_t *bits = stringToBits(str, len);
	for (i = 0; i < neededPixels; i++)
		img.pix[i].b = setBit(img.pix[i].b, 0, bits[i]);
	
	return 1;
}

int main(int argc, char* argv[]) {
	char *help = 
		"USAGE: secret-hide INPUT_IMG INPUT_TEXT OUTPUT_IMG\n"
		"EXAMPLE: secret-hide Thoth.png \"#MaliceNoAlex says sup!\" ThothX.png\n";
	
	if (argc != 4 || !endsWith(argv[1], ".png")) {
		printf(help);
		return 1;
	}
	
	char *input_img  = argv[1], // "Thoth.png"
		 *input_text = argv[2], // "#MaliceNoAlex says sup!"
		 *output_img = argv[3]; // "ThothX.png"
		 
	tpImage img = tpLoadPNG(input_img);
	if (encode(img, input_text)) {
		tpSavePNG(output_img, &img);
		printf("<DONE>\n");
	} else {
		printf("ERROR: TEXT IS TOO LONG TO BE STORED IN THE GIVEN PNG\n");
	}
	
	return 0;
}
