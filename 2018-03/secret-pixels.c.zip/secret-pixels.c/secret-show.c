#include "secret.h"

char *decode(tpImage img) {
	const int countPixels = img.h * img.w;
	int result_len = 0;
	char *result_str = malloc(0);
	char *str = malloc(countPixels / 8 * sizeof(char));
	int s = 0; // str last index
	int i, k = 0; // like a counter
	char c = 0;
	for (i = 0; i < countPixels; i++) {
		k++;
		c = (c << 1) + getBit(img.pix[i].b, 0);
		if (k == 8) {
			// every 8 bits, save the character if it's printable and then rest
			if (isprint(c)) str[s++] = c;
			c = 0; k = 0;
		}
	}
	str[s] = '\0';

	char *pEOM = strstr(str, EOM);
	if (!pEOM) {
		return "<FOUND NO HIDDEN MESSAGE>";
	} else {
		result_len = pEOM - str;
		realloc(result_str, result_len * sizeof(char));
		strncpy(result_str, str, result_len);
		result_str[result_len] = '\0';
		return result_str;
	}	
}

int main(int argc, char* argv[]) {
	char *help =
		"USAGE: secret-show INPUT_IMG\n"
		"EXAMPLE: secret-show ThothX.png\n";
	
	if (argc != 2 || !endsWith(argv[1], ".png")) {
		printf(help);
		return 1;
	}
	
	char *input_img = argv[1];
	
	tpImage img = tpLoadPNG(input_img);
	char *decoded = decode(img);
	printf("\n%s\n", decoded);
	
	return 0;
}
