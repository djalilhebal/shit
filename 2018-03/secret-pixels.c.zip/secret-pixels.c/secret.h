﻿// SECRET PIXELS - common fuctions
#include <stdio.h> // printf()
#include <stdlib.h> // malloc(), realloc()
#include <string.h> // strlen(), strcpy(), strcat()
#include <ctype.h> // isprint()

#define TINYPNG_IMPLEMENTATION 1
#include "tinypng.h" // needs to be compiled with -std=C99

typedef short bit_t;

const char *EOM = "EOM"; // "End Of Message" :p

// inspired by JavaScript's String.prototype.endsWith method
int endsWith(char *str, char *sub) {
	int length = strlen(str);
	int i, len = strlen(sub);
	if (len > length) return 0;
	for (i = 1; i <= len; i++)
		if (str[length - i] != sub[len - i])
			return 0;
	return 1;
};

int setBit(int num, int pos, int bit) {
   return (num & ~(1 << pos)) | (bit << pos);
};

bit_t getBit(int num, int pos) {
   return (num >> pos) & 1;
}

bit_t *stringToBits(char *str, int len) {
  int i, j, code;
  bit_t *bits = malloc( len * 8 * sizeof(bit_t) );
  for (i = 0; i < len; i++) {
    // convert each character to an array of bits
    // 'K' -> 75 -> {0,1,0,0,1,0,1,1}
    code = str[i];
    for (j = 7; j >= 0; j--) {
      bits[i * 8 + 7 - j] = getBit(code, j);
    }
  }
  return bits;
}
